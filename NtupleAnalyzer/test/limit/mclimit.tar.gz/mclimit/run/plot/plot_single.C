#include <iostream>

#include "AtlasLabels.C"

void setStyle(){
  gROOT->SetStyle("Plain");
  
  gStyle->SetTitleSize(0.05593);
  gStyle->SetTitleSize(0.05,"xyz");
  gStyle->SetLabelSize(0.047,"xyz");
  gStyle->SetTitleFont(132,"xyz");
  gStyle->SetTitleFont(132,"t");
  gStyle->SetLabelFont(132,"xyz");
  gStyle->SetTitleYOffset(1.2);
  
  gStyle->SetHistLineWidth(1);
  
  gStyle->SetTitleBorderSize(0);
  gStyle->SetNdivisions(505,"xyz");
  gStyle->SetOptStat(0000);
  gStyle->SetPadBottomMargin(0.14);
  gStyle->SetPadLeftMargin(0.14);
  gStyle->SetPalette(1);
  
  gStyle->SetLineColor(0);
  
  gStyle->SetMarkerStyle(20);
  gStyle->SetMarkerSize(0.5);
  gStyle->SetPadTickX(1);
  gStyle->SetPadTickY(1);
  gStyle->SetErrorX(0.000001);
  gStyle->SetMarkerStyle(20);
  gStyle->SetMarkerSize(1.1);
  gStyle->SetHistLineWidth(2.);
  gROOT->ForceStyle();

}

void plot_single(){

   gROOT->SetBatch();
   
   setStyle();
   
   gROOT->ProcessLine(".L readLimits.C");

   std::string sig = "WR";
   std::string type = "Majorana";
   std::string intL = "14.3";
   std::string ener = "8";
   std::string rat = "2";
   std::string chan = "ee+#mu#mu";
   std::string charg = "SSOS";
   bool mix = 0;
   bool drawObs = 0;
   std::string sel = "m1ovm2eq"+rat;
   std::string fname = "../results/bayes_"+sig+"_eemm"+charg+type+".txt";
   std::string ndim = "1d";

   double xsecF = 1.;
   if( type == "Dirac" ) xsecF = 2.;
   
   const int nMax = 1000;
   double m1[nMax],m2[nMax],
     med[nMax],s2p[nMax],s1p[nMax],s1m[nMax],s2m[nMax],obs[nMax],
     xsec[nMax],dum1[nMax],dum2[nMax],pval[nMax];
   
   int np = readLimits(m1,m2,med,s2p,s1p,s1m,s2m,obs,xsec,dum1,dum2,pval,sel,xsecF,fname,ndim);
   
   const int nrm = np;
   double *nr_mass = &m2;
   double *theory_xsec = &xsec;
   double *mel = &med;
   double *sig1_p = &s1p;
   double *sig1_n = &s1m;
   double *sig2_p = &s2p;
   double *sig2_n = &s2m;
   double *data = &obs;

   const int nel = nrm*2+1;
   double x[nel], y2_p[nel], y2_n[nel], y1_p[nel], y1_n[nel], mel2[nrm], data2[nrm];
   
   for(int i=0;i<nrm;i++)
     {	
	mel2[i] = mel[i] * theory_xsec[i];
	data2[i] = data[i] * theory_xsec[i];

	x[i] = nr_mass[i];
	x[nrm+i] = nr_mass[nrm-1-i];

	y2_p[i] = sig2_p[i] * theory_xsec[i];
	y2_p[nrm+i] = mel[nrm-1-i] * theory_xsec[nrm-1-i];

	y2_n[i] = sig2_n[i] * theory_xsec[i];
	y2_n[nrm+i] = mel[nrm-1-i] * theory_xsec[nrm-1-i];

	y1_p[i] = sig1_p[i] * theory_xsec[i];
	y1_p[nrm+i] = mel[nrm-1-i] * theory_xsec[nrm-1-i];
	
	y1_n[i] = sig1_n[i] * theory_xsec[i];
	y1_n[nrm+i] = mel[nrm-1-i] * theory_xsec[nrm-1-i];
     }
      
   x[int(nrm*2)] = nr_mass[0];
   y2_p[int(nrm*2)] = sig2_p[0] * theory_xsec[0];
   y2_n[int(nrm*2)] = sig2_n[0] * theory_xsec[0];
   y1_p[int(nrm*2)] = sig1_p[0] * theory_xsec[0];
   y1_n[int(nrm*2)] = sig1_n[0] * theory_xsec[0];
   
   TCanvas *c1 = new TCanvas();

   TGraph *g_mel = new TGraph(nrm,nr_mass,mel2);
   g_mel->SetTitle("");
   g_mel->SetLineColor(kBlack);
   g_mel->SetLineWidth(2);
   g_mel->Draw("AL");
   g_mel->SetMaximum(1);
   g_mel->SetMinimum(0.0001);

   TGraph *g_data = new TGraph(nrm,nr_mass,data2);
   g_data->SetTitle("");
   g_data->SetLineColor(kRed);
   g_data->SetLineWidth(2);

   TGraph *g_theory = new TGraph(nrm,nr_mass,theory_xsec);
   g_theory->SetTitle("");
   g_theory->SetLineColor(kBlack);
   g_theory->SetLineStyle(2);
   g_theory->SetLineWidth(2);
   
   TPolyLine *pl2_p = new TPolyLine(nel,x,y2_p);
   pl2_p->SetFillColor(kYellow);
   pl2_p->Draw("fSAME");

   TPolyLine *pl2_n = new TPolyLine(nel,x,y2_n);
   pl2_n->SetFillColor(kYellow);
   pl2_n->Draw("fSAME");

   TPolyLine *pl1_p = new TPolyLine(nel,x,y1_p);
   pl1_p->SetFillColor(kGreen);
   pl1_p->Draw("fSAME");

   TPolyLine *pl1_n = new TPolyLine(nel,x,y1_n);
   pl1_n->SetFillColor(kGreen);
   pl1_n->Draw("fSAME");
   
   g_mel->Draw("L");
   g_mel->GetXaxis()->SetTitle("#font[52]{m_{N}} [GeV]");
   g_mel->GetYaxis()->SetTitle("#sigma [pb]");

   if( drawObs )
     g_data->Draw("L");
   
   g_theory->Draw("L");
   
   TLegend *l1 = new TLegend(0.68,0.64,0.87,0.83);
   l1->SetLineColor(0);
   l1->AddEntry(g_mel,"Expected","l");
   l1->AddEntry(g_theory,"Theory","l");
   l1->AddEntry(pl1_p,"68%","f");
   l1->AddEntry(pl2_p,"95%","f");
   
   if( drawObs )
     l1->AddEntry(g_data,"Observed","l");
   
   l1->SetFillColor(0);
   std::string intLLab = "#intLdt = "+intL+" fb^{-1}";
   l1->SetHeader(intLLab.c_str());
   l1->Draw("SAME");

   TLatex lEner;
   lEner.SetTextSize(0.044);
   lEner.SetNDC();
   lEner.SetTextColor(kBlack);
   std::string enerLab = "#font[42]{#sqrt[]{s} = "+ener+" TeV}";
   lEner.DrawLatex(0.45,0.80,enerLab.c_str());

   std::string lChanLab = "#font[42]{"+chan+"}";
   
   TLatex lChan;
   lChan.SetTextSize(0.044);
   lChan.SetNDC();
   lChan.SetTextColor(kBlack);
   if( mix )
     {
	lChan.DrawLatex(0.68,0.55,"#font[42]{With mixing}");
     }   
   else
     {	
	lChan.DrawLatex(0.68,0.55,"#font[42]{No mixing}");
     }   
   lChan.DrawLatex(0.68,0.50,lChanLab.c_str());
   lChan.Draw();

   TLatex lMass;
   lMass.SetTextSize(0.044);
   lMass.SetNDC();
   lMass.SetTextColor(kBlack);
   std::string lMassLab = "#font[42]{m_{W_{R}} = "+rat+" m_{N}}";
   lMass.DrawLatex(0.68,0.45,lMassLab.c_str());
   lMass.Draw();
   
   TLegend *lChar;
   lChar = new TLegend(0.18,0.70,0.18,0.70);
   lChar->SetLineColor(0);
   lChar->SetFillColor(0);
   lChar->SetTextSize(0.058);
   std::string chargStr = charg;
   if( charg == "SSOS" ) chargStr = "SS+OS";
   lChar->SetHeader(chargStr.c_str());
   lChar->Draw();

   TLegend *lNType = new TLegend(0.20,0.25,0.20,0.20);
   lNType->SetLineColor(0);
   lNType->SetFillColor(0);
   lNType->SetTextSize(0.055);
   std::string lNTypeLab = "#font[62]{N_{"+type+"}}";
   lNType->SetHeader(lNTypeLab.c_str());
   lNType->Draw();

   ATLASLabel(0.18,0.830,"Internal",kBlack);
   
   c1->SetLogy(1);
   c1->GetFrame()->SetFillColor(kWhite);
   c1->Update();
   c1->Draw();   
   c1->Print("pics/plot_single.eps");
   
   gApplication->Terminate();
}
