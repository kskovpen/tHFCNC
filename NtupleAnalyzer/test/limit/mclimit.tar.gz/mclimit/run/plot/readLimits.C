int readLimits(double *m1,
	       double *m2,
	       double *med,
	       double *s2p,
	       double *s1p,
	       double *s1m,
	       double *s2m,
	       double *obs,
	       double *xsec,
	       double *dum1,
	       double *dum2,
	       double *pval,
	       std::string sel,
	       double xsecF,
	       std::string fname,
	       std::string ndim
	       )
{
   std::ifstream flim(fname.c_str());

   int il = 0;
   
   double m1v,m2v,medv,s2pv,s1pv,s1mv,s2mv,obsv,
     xsecv,dum1v,dum2v,pvalv;   

   if( !flim.is_open() )
     {
	std::cout << fname << " does not exist" << std::endl;
	return 0;
     }   
   
   while( !flim.eof() )
     {
	flim >> m1v >> m2v >>
	  medv >> s2pv >> s1pv >> s1mv >> s2mv >>
	  obsv >> xsecv >> dum1v >> dum2v >> pvalv;
	
	bool all_PASS = (sel == "");
	bool m1ovm2eq2_PASS = (sel == "m1ovm2eq2" && m2v > 0 && m1v/m2v == 2.);
	bool m1ovm2eq4_PASS = (sel == "m1ovm2eq4" && m2v > 0 && m1v/m2v == 4.);
	bool m1ovm2eq8_PASS = (sel == "m1ovm2eq8" && m2v > 0 && m1v/m2v == 8.);
	
	if( 
	    all_PASS ||
	    m1ovm2eq2_PASS ||
	    m1ovm2eq4_PASS ||
	    m1ovm2eq8_PASS
	    )
	  {
	     if( ndim == "2d" )
	       {
		  m1v = m1v/1000.;
		  m2v = m2v/1000.;
	       }	     
	     
	     m1[il] = m1v;
	     m2[il] = m2v;
	     med[il] = medv/xsecF;
	     s2p[il] = s2pv/xsecF;
	     s1p[il] = s1pv/xsecF;
	     s1m[il] = s1mv/xsecF;
	     s2m[il] = s2mv/xsecF;
	     obs[il] = obsv/xsecF;
	     xsec[il] = xsecv*xsecF;
	     dum1[il] = dum1v;
	     dum2[il] = dum2v;
	     pval[il] = pvalv;
	     
	     il++;
	  }       
     }
   
   int np = il-1;
   
   flim.close();
   
   return np;
}
