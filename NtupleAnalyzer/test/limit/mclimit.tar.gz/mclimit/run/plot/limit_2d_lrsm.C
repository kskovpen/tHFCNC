#include "TGraph2D.h"
#include "TLegend.h"
#include "TPaveText.h"
#include "TGraph.h"
#include "TAxis.h"
#include "TPad.h"
#include "TCanvas.h"
#include <iostream>
#include "TStyle.h"
#include "TH2.h"

#include "TList.h"
#include "TObjArray.h"
#include "TROOT.h"
#include <vector>

#include "AtlasLabels.C"

void setStyle(){
   gROOT->SetStyle("Plain");
   
   gStyle->SetTitleSize(0.05593);
   gStyle->SetTitleSize(0.05,"xyz");
//   gStyle->SetTitleSize(0.0,"xyz");
//   gStyle->SetLabelSize(0.0,"xyz");
   gStyle->SetLabelSize(0.047,"xyz");
   gStyle->SetTitleFont(132,"xyz");
   gStyle->SetTitleFont(132,"t");
   gStyle->SetLabelFont(132,"xyz");
   gStyle->SetTitleYOffset(1.0);
   gStyle->SetTitleXOffset(1.2);
   
   gStyle->SetHistLineWidth(1);
   
   gStyle->SetTitleBorderSize(0);
   gStyle->SetNdivisions(505,"xyz");
   gStyle->SetOptStat(0000);
   gStyle->SetPadBottomMargin(0.14);
   gStyle->SetPadLeftMargin(0.14);
   gStyle->SetPalette(7);
  
   gStyle->SetLineColor(0);
   
   gStyle->SetMarkerStyle(20);
   gStyle->SetMarkerSize(0.5);
   gStyle->SetPadTickX(1);
   gStyle->SetPadTickY(1);
   gStyle->SetErrorX(0.000001);
   gStyle->SetMarkerStyle(20);
   gStyle->SetMarkerSize(1.1);
   gStyle->SetHistLineWidth(2.);
   gROOT->ForceStyle();
}

void limit_2d_lrsm()
{
   gROOT->SetBatch();
   setStyle();
   gStyle->SetHatchesSpacing(1.5);

   gROOT->ProcessLine(".L readLimits.C");

   std::string sig = "WR";
//   std::string type = "Majorana";
   std::string type = "Dirac";
   std::string intL = "20.3";
   std::string ener = "8";
//   std::string charg = "SSOS";
   std::string charg = "OS";
   bool mix = 1;
   std::string mixStr = "";
   if( mix ) mixStr = "Mix";
   bool drawObs = 0;
   std::string sel = "";
   std::string ndim = "2d";
   std::string fname_l1 = "../results/bayes_"+sig+"_ee"+charg+type+mixStr+".txt";
   std::string fname_l2 = "../results/bayes_"+sig+"_mm"+charg+type+mixStr+".txt";
   std::string fname_l3 = "../results/bayes_"+sig+"_em"+charg+type+mixStr+".txt";
   std::string fname_combNoMix = "../results/bayes_"+sig+"_eemm"+charg+type+mixStr+".txt";
   std::string fname_combMix = "../results/bayes_"+sig+"_eemmem"+charg+type+mixStr+".txt";

   double xsecF = 1.;
   if( type == "Dirac" ) xsecF = 2.;
   
   const int nMax = 1000;
   
   double m1_l1[nMax],m2_l1[nMax],
     med_l1[nMax],s2p_l1[nMax],s1p_l1[nMax],s1m_l1[nMax],s2m_l1[nMax],obs_l1[nMax],
     xsec_l1[nMax],dum1_l1[nMax],dum2_l1[nMax],pval_l1[nMax];   
   double m1_l2[nMax],m2_l2[nMax],
     med_l2[nMax],s2p_l2[nMax],s1p_l2[nMax],s1m_l2[nMax],s2m_l2[nMax],obs_l2[nMax],
     xsec_l2[nMax],dum1_l2[nMax],dum2_l2[nMax],pval_l2[nMax];   
   double m1_l3[nMax],m2_l3[nMax],
     med_l3[nMax],s2p_l3[nMax],s1p_l3[nMax],s1m_l3[nMax],s2m_l3[nMax],obs_l3[nMax],
     xsec_l3[nMax],dum1_l3[nMax],dum2_l3[nMax],pval_l3[nMax];   
   double m1_combNoMix[nMax],m2_combNoMix[nMax],
     med_combNoMix[nMax],s2p_combNoMix[nMax],s1p_combNoMix[nMax],s1m_combNoMix[nMax],s2m_combNoMix[nMax],obs_combNoMix[nMax],
     xsec_combNoMix[nMax],dum1_combNoMix[nMax],dum2_combNoMix[nMax],pval_combNoMix[nMax];   
   double m1_combMix[nMax],m2_combMix[nMax],
     med_combMix[nMax],s2p_combMix[nMax],s1p_combMix[nMax],s1m_combMix[nMax],s2m_combMix[nMax],obs_combMix[nMax],
     xsec_combMix[nMax],dum1_combMix[nMax],dum2_combMix[nMax],pval_combMix[nMax];
   
   int np_l1 = readLimits(m1_l1,m2_l1,med_l1,s2p_l1,s1p_l1,s1m_l1,s2m_l1,obs_l1,
			  xsec_l1,dum1_l1,dum2_l1,
			  pval_l1,sel,xsecF,fname_l1,ndim);
   int np_l2 = readLimits(m1_l2,m2_l2,med_l2,s2p_l2,s1p_l2,s1m_l2,s2m_l2,obs_l2,
			  xsec_l2,dum1_l2,dum2_l2,
			  pval_l2,sel,xsecF,fname_l2,ndim);
   int np_l3 = readLimits(m1_l3,m2_l3,med_l3,s2p_l3,s1p_l3,s1m_l3,s2m_l3,obs_l3,
			  xsec_l3,dum1_l3,dum2_l3,
			  pval_l3,sel,xsecF,fname_l3,ndim);
   int np_combNoMix = readLimits(m1_combNoMix,m2_combNoMix,med_combNoMix,s2p_combNoMix,s1p_combNoMix,s1m_combNoMix,s2m_combNoMix,obs_combNoMix,
				 xsec_combNoMix,dum1_combNoMix,dum2_combNoMix,
				 pval_combNoMix,sel,xsecF,fname_combNoMix,ndim);
   int np_combMix = readLimits(m1_combMix,m2_combMix,med_combMix,s2p_combMix,s1p_combMix,s1m_combMix,s2m_combMix,obs_combMix,
			       xsec_combMix,dum1_combMix,dum2_combMix,
			       pval_combMix,sel,xsecF,fname_combMix,ndim);   
   
   TGraph2D *tgc_med_l1,*tgc_med_l2,*tgc_med_l3,*tgc_med_combNoMix,*tgc_med_combMix;
   TGraph2D *tgc_obs_l1,*tgc_obs_l2,*tgc_obs_l3,*tgc_obs_combNoMix,*tgc_obs_combMix;
  
   if( np_l1 )
     {	
	tgc_med_l1 = new TGraph2D(np_l1,m1_l1,m2_l1,med_l1);
	tgc_med_l1->SetNpx(35);
	tgc_med_l1->SetNpy(40);
	tgc_med_l1->SetName("tgc_med_l1");

	tgc_obs_l1 = new TGraph2D(np_l1,m1_l1,m2_l1,obs_l1);
	tgc_obs_l1->SetNpx(35);
	tgc_obs_l1->SetNpy(40);
	tgc_obs_l1->SetName("tgc_obs_l1");
     }   
   if( np_l2 )
     {	
	tgc_med_l2 = new TGraph2D(np_l2,m1_l2,m2_l2,med_l2);
	tgc_med_l2->SetNpx(35);
	tgc_med_l2->SetNpy(40);
	tgc_med_l2->SetName("tgc_med_l2");

	tgc_obs_l2 = new TGraph2D(np_l2,m1_l2,m2_l2,obs_l2);
	tgc_obs_l2->SetNpx(35);
	tgc_obs_l2->SetNpy(40);
	tgc_obs_l2->SetName("tgc_obs_l2");
     }   
    if( np_l3 )
     {	
	tgc_med_l3 = new TGraph2D(np_l3,m1_l3,m2_l3,med_l3);
	tgc_med_l3->SetNpx(35);
	tgc_med_l3->SetNpy(40);
	tgc_med_l3->SetName("tgc_med_l3");

	tgc_obs_l3 = new TGraph2D(np_l3,m1_l3,m2_l3,obs_l3);
	tgc_obs_l3->SetNpx(35);
	tgc_obs_l3->SetNpy(40);
	tgc_obs_l3->SetName("tgc_obs_l3");
     }   
    if( np_combNoMix )
     {	
	tgc_med_combNoMix = new TGraph2D(np_combNoMix,m1_combNoMix,m2_combNoMix,med_combNoMix);
	tgc_med_combNoMix->SetNpx(35);
	tgc_med_combNoMix->SetNpy(40);
	tgc_med_combNoMix->SetName("tgc_med_combNoMix");

	tgc_obs_combNoMix = new TGraph2D(np_combNoMix,m1_combNoMix,m2_combNoMix,obs_combNoMix);
	tgc_obs_combNoMix->SetNpx(35);
	tgc_obs_combNoMix->SetNpy(40);
	tgc_obs_combNoMix->SetName("tgc_obs_combNoMix");
     }   
    if( np_combMix )
     {	
	tgc_med_combMix = new TGraph2D(np_combMix,m1_combMix,m2_combMix,med_combMix);
	tgc_med_combMix->SetNpx(35);
	tgc_med_combMix->SetNpy(40);
	tgc_med_combMix->SetName("tgc_med_combMix");

	tgc_obs_combMix = new TGraph2D(np_combMix,m1_combMix,m2_combMix,obs_combMix);
	tgc_obs_combMix->SetNpx(35);
	tgc_obs_combMix->SetNpy(40);
	tgc_obs_combMix->SetName("tgc_obs_combMix");
     }   
   
   TCanvas *tc = new TCanvas("tc","",1000,800);

   std::vector< TGraph* > cont_med_l1;
   std::vector< TGraph* > cont_med_l2;
   std::vector< TGraph* > cont_med_l3;
   std::vector< TGraph* > cont_med_combNoMix;
   std::vector< TGraph* > cont_med_combMix;

   std::vector< TGraph* > cont_obs_l1;
   std::vector< TGraph* > cont_obs_l2;
   std::vector< TGraph* > cont_obs_l3;
   std::vector< TGraph* > cont_obs_combNoMix;
   std::vector< TGraph* > cont_obs_combMix;
   
   if( np_l1 )
     {	
	cont_med_l1 = getContour(tgc_med_l1,tc,0);
	cont_obs_l1 = getContour(tgc_obs_l1,tc,0);
     }   
   if( np_l2 )
     {	
	cont_med_l2 = getContour(tgc_med_l2,tc,0);
	cont_obs_l2 = getContour(tgc_obs_l2,tc,0);
     }  
   if( np_l3 )
     {	
	cont_med_l3 = getContour(tgc_med_l3,tc,0);
	cont_obs_l3 = getContour(tgc_obs_l3,tc,0);
     }   
   if( np_combNoMix )
     {	
	cont_med_combNoMix = getContour(tgc_med_combNoMix,tc,0);
	cont_obs_combNoMix = getContour(tgc_obs_combNoMix,tc,0);
     }   
   if( np_combMix )
     {	
	cont_med_combMix = getContour(tgc_med_combMix,tc,0);
	cont_obs_combMix = getContour(tgc_obs_combMix,tc,0);
     }   
   
/*   double m1_c[1] = {0};
   double m2_c[1] = {0};
   double xs_c[1] = {0};
   
   TGraph2D *tgx_canv = new TGraph2D(1,m1_c,m2_c,xs_c);
   tgx_canv->SetTitle("");
   tgx_canv->GetYaxis()->SetTitle("#font[52]{m_{N}} #font[42]{[TeV]}");
   tgx_canv->GetXaxis()->SetTitle("#font[52]{m_{W_{R}}} #font[42]{[TeV]}");   
   tgx_canv->Draw("");*/

   double xmax = 3.6;
   double ymax = 2.8;
   
   if( sig == "ZR" )
     {
	xmax = 3.0;
	ymax = 1.5;
     }
   
   TH2F *hr = new TH2F("hr","",10,0.6,xmax,10,0.,ymax);
   hr->GetYaxis()->SetTitle("#font[52]{m_{N}} #font[42]{[TeV]}");
   if( sig == "WR" )
     hr->GetXaxis()->SetTitle("#font[52]{m_{W_{R}}} #font[42]{[TeV]}");
   else if( sig == "ZR" )
     hr->GetXaxis()->SetTitle("#font[52]{m_{Z_{R}}} #font[42]{[TeV]}");
   hr->SetNdivisions(505,"x");
   hr->SetNdivisions(505,"y");
   hr->Draw("");
   hr->GetYaxis()->SetRangeUser(0,ymax);

   for(int j=0;j<cont_med_l1.size();j++)
     {
	cont_med_l1[j]->SetLineStyle(8);
	cont_med_l1[j]->SetLineWidth(4);
	cont_med_l1[j]->SetLineColor(kBlack);
	int nel_l1 = cont_med_l1[j]->GetN();
	int nel1_l1 = nel_l1+2;
	double *x_poi_l1 = new double[nel1_l1];
	double *y_poi_l1 = new double[nel1_l1];
	if( j == 0 )
	  {		  
	     for(int ip=0;ip<nel_l1;ip++)
	       cont_med_l1[j]->GetPoint(ip,x_poi_l1[ip],y_poi_l1[ip]);
	     cont_med_l1[j]->SetPoint(0,0.6,0.05);
	     cont_med_l1[j]->SetPoint(1,x_poi_l1[0],0.05);
	     for(int ip=0;ip<nel_l1;ip++)
	       cont_med_l1[j]->SetPoint(ip+2,x_poi_l1[ip],y_poi_l1[ip]);
	     
	     if( sig == "WR" )
//	       interp(cont_med_l1[j],nel_l1,1.250);
	     interp(cont_med_l1[j],nel_l1,1.1);
	     if( sig == "ZR" )
	       interp(cont_med_l1[j],nel_l1,1.4);
//	     interpSHARP(cont_med_l1[j],nel_l1,1.3,0.45,0.);
	  }
	cont_med_l1[j]->Draw("L");
	delete x_poi_l1;
	delete y_poi_l1;
     }

   for(int j=0;j<cont_med_l2.size();j++)
     {
	cont_med_l2[j]->SetLineStyle(8);
	cont_med_l2[j]->SetLineWidth(4);
	cont_med_l2[j]->SetLineColor(kBlue-6);
	int nel_l2 = cont_med_l2[j]->GetN();
	int nel1_l2 = nel_l2+2;
	double *x_poi_l2 = new double[nel1_l2];
	double *y_poi_l2 = new double[nel1_l2];
	if( j == 0 )
	  {		  
	     for(int ip=0;ip<nel_l2;ip++)
	       cont_med_l2[j]->GetPoint(ip,x_poi_l2[ip],y_poi_l2[ip]);
	     cont_med_l2[j]->SetPoint(0,0.6,0.05);
	     cont_med_l2[j]->SetPoint(1,x_poi_l2[0],0.05);
	     for(int ip=0;ip<nel_l2;ip++)
	       cont_med_l2[j]->SetPoint(ip+2,x_poi_l2[ip],y_poi_l2[ip]);
	     
	     if( sig == "WR" )
//	       interp(cont_med_l2[j],nel_l2,1.250);
	     interp(cont_med_l2[j],nel_l2,1.1);
	     if( sig == "ZR" )
	       interp(cont_med_l2[j],nel_l2,1.4);
	  }
	cont_med_l2[j]->Draw("L");
	delete x_poi_l2;
	delete y_poi_l2;
     }
   
   for(int j=0;j<cont_med_l3.size();j++)
     {
	cont_med_l3[j]->SetLineStyle(8);
	cont_med_l3[j]->SetLineWidth(4);
	cont_med_l3[j]->SetLineColor(kGreen-6);
	int nel_l3 = cont_med_l3[j]->GetN();
	int nel1_l3 = nel_l3+2;
	double *x_poi_l3 = new double[nel1_l3];
	double *y_poi_l3 = new double[nel1_l3];
	if( j == 0 )
	  {		  
	     for(int ip=0;ip<nel_l3;ip++)
	       cont_med_l3[j]->GetPoint(ip,x_poi_l3[ip],y_poi_l3[ip]);
	     cont_med_l3[j]->SetPoint(0,0.6,0.05);
	     cont_med_l3[j]->SetPoint(1,x_poi_l3[0],0.05);
	     for(int ip=0;ip<nel_l3;ip++)
	       cont_med_l3[j]->SetPoint(ip+2,x_poi_l3[ip],y_poi_l3[ip]);
	     
	     if( sig == "WR" )
	       interp(cont_med_l3[j],nel_l3,1.250);
	     if( sig == "ZR" )
	       interp(cont_med_l3[j],nel_l3,1.4);
	  }
	cont_med_l3[j]->Draw("L");
	delete x_poi_l3;
	delete y_poi_l3;
     }
   
   for(int j=0;j<cont_med_combNoMix.size();j++)
     {
	cont_med_combNoMix[j]->SetLineStyle(8);
	cont_med_combNoMix[j]->SetLineWidth(4);
	cont_med_combNoMix[j]->SetLineColor(kRed-6);
	int nel_combNoMix = cont_med_combNoMix[j]->GetN();
	int nel1_combNoMix = nel_combNoMix+2;
	double *x_poi_combNoMix = new double[nel1_combNoMix];
	double *y_poi_combNoMix = new double[nel1_combNoMix];
	if( j == 0 )
	  {		  
	     for(int ip=0;ip<nel_combNoMix;ip++)
	       cont_med_combNoMix[j]->GetPoint(ip,x_poi_combNoMix[ip],y_poi_combNoMix[ip]);
	     cont_med_combNoMix[j]->SetPoint(0,0.6,0.05);
	     cont_med_combNoMix[j]->SetPoint(1,x_poi_combNoMix[0],0.05);
	     for(int ip=0;ip<nel_combNoMix;ip++)
	       cont_med_combNoMix[j]->SetPoint(ip+2,x_poi_combNoMix[ip],y_poi_combNoMix[ip]);
	     
	     if( sig == "WR" )
	       interp(cont_med_combNoMix[j],nel_combNoMix,1.250);
	     if( sig == "ZR" )
	       interp(cont_med_combNoMix[j],nel_combNoMix,1.4);
	  }
	cont_med_combNoMix[j]->Draw("L");
	delete x_poi_combNoMix;
	delete y_poi_combNoMix;
     }

   for(int j=0;j<cont_med_combMix.size();j++)
     {
	cont_med_combMix[j]->SetLineStyle(8);
	cont_med_combMix[j]->SetLineWidth(4);
	cont_med_combMix[j]->SetLineColor(kRed-6);
	int nel_combMix = cont_med_combMix[j]->GetN();
	int nel1_combMix = nel_combMix+2;
	double *x_poi_combMix = new double[nel1_combMix];
	double *y_poi_combMix = new double[nel1_combMix];
	if( j == 0 )
	  {		  
	     for(int ip=0;ip<nel_combMix;ip++)
	       cont_med_combMix[j]->GetPoint(ip,x_poi_combMix[ip],y_poi_combMix[ip]);
	     cont_med_combMix[j]->SetPoint(0,0.6,0.05);
	     cont_med_combMix[j]->SetPoint(1,x_poi_combMix[0],0.05);
	     for(int ip=0;ip<nel_combMix;ip++)
	       cont_med_combMix[j]->SetPoint(ip+2,x_poi_combMix[ip],y_poi_combMix[ip]);
	     
	     if( sig == "WR" )
	       interp(cont_med_combMix[j],nel_combMix,1.250);
	     if( sig == "ZR" )
	       interp(cont_med_combMix[j],nel_combMix,1.4);
	  }
	cont_med_combMix[j]->Draw("L");
	delete x_poi_combMix;
	delete y_poi_combMix;
     }
   
/*
   TGaxis *yaxis = new TGaxis(gPad->GetUxmin(), gPad->GetUymin()-50.,
			      gPad->GetUxmin(), gPad->GetUymax(),0.,3.6,505);
   yaxis->ImportAxisAttributes(tgx_canv->GetYaxis());
   yaxis->SetLabelSize(0.047);
   yaxis->SetTitleSize(0.05);
   yaxis->Draw();

   TGaxis *xaxis = new TGaxis(gPad->GetUxmin(), gPad->GetUymin()-50.,
			      gPad->GetUxmax(), gPad->GetUymin()-50.,0.6,3.5,505);
   xaxis->ImportAxisAttributes(tgx_canv->GetXaxis());
   xaxis->SetLabelSize(0.047);
   xaxis->SetTitleSize(0.05);
   xaxis->Draw();*/

   if( sig == "WR" )
     {	
	TF1 *f1 = new TF1("f1","[0]*x",0.6,2.9);
	f1->SetParameter(0,1.);
	f1->SetLineStyle(2);
	f1->SetLineWidth(1);
	f1->Draw("same");
     }
   else if( sig == "ZR" )
     {
	TF1 *f1 = new TF1("f1","[0]*x/2",0.6,2.9);
	f1->SetParameter(0,1.);
	f1->SetLineStyle(2);
	f1->SetLineWidth(1);
	f1->Draw("same");
     }   

   if( sig == "WR" )
     {	
	TLegend *l1 = new TLegend(0.68,0.83,0.68,0.83);
	l1->SetLineColor(0);
	l1->SetFillColor(0);
	l1->SetTextSize(0.040);
	std::string intLLab = "#intLdt = "+intL+" fb^{-1}";
	l1->SetHeader(intLLab.c_str());
	l1->Draw();
     }   
   if( sig == "ZR" )
     {	
	TLegend *l1 = new TLegend(0.68,0.65,0.68,0.65);
	l1->SetLineColor(0);
	l1->SetFillColor(0);
	l1->SetTextSize(0.040);
	std::string intLLab = "#intLdt = "+intL+" fb^{-1}";
	l1->SetHeader(intLLab.c_str());
	l1->Draw();
     }   

   TLegend *l2;
   l2 = new TLegend(0.16,0.88,0.40,0.69);
   l2->SetLineColor(0);
   l2->SetFillColor(0);
   l2->SetTextSize(0.038);
   
   if( np_l1)
     l2->AddEntry(cont_med_l1[0],"#font[42]{ee, Expected}","l");
   
   if( np_l2 )
     l2->AddEntry(cont_med_l2[0],"#font[42]{#mu#mu, Expected}","l");

   if( mix )
     {
	if( np_l3 )
	  l2->AddEntry(cont_med_l3[0],"#font[42]{e#mu, Expected}","l");
	
	if( np_combMix )
	  l2->AddEntry(cont_med_combMix[0],"#font[42]{ee+#mu#mu+e#mu, Expected}","l");
     }   
   else
     {	
	if( np_combNoMix )
	  l2->AddEntry(cont_med_combNoMix[0],"#font[42]{ee+#mu#mu, Expected}","l");
     }
   
   l2->Draw();

   TLegend *l3;
   l3 = new TLegend(0.18,0.57,0.18,0.57);
   l3->SetLineColor(0);
   l3->SetFillColor(0);
   l3->SetTextSize(0.058);
   std::string chargStr = charg;
   if( charg == "SSOS" ) chargStr = "SS+OS";
   l3->SetHeader(chargStr.c_str());
   l3->Draw();

   TLegend *l5 = new TLegend(0.20,0.25,0.20,0.20);
   l5->SetLineColor(0);
   l5->SetFillColor(0);
   l5->SetTextSize(0.055);
   std::string typeStr = "#font[62]{N_{"+type+"}}";
   l5->SetHeader(typeStr.c_str());
   l5->Draw();

   if( sig == "WR" )
     {	
	TLatex l7;
	l7.SetTextSize(0.044);
	l7.SetNDC();
	l7.SetTextColor(kBlack);
	std::string enerStr = "#font[42]{#sqrt[]{s} = "+ener+" TeV}";
	l7.DrawLatex(0.71,0.74,enerStr.c_str());
     }   
   if( sig == "ZR" )
     {	
	TLatex l7;
	l7.SetTextSize(0.044);
	l7.SetNDC();
	l7.SetTextColor(kBlack);
	std::string enerStr = "#font[42]{#sqrt[]{s} = "+ener+" TeV}";
	l7.DrawLatex(0.71,0.58,enerStr.c_str());
     }   

   TLatex l;
   l.SetTextSize(0.037);
   l.SetNDC();
   l.SetTextColor(kBlack);
   if( sig == "WR" )
     {	
	l.SetTextAngle(38);
	l.DrawLatex(0.16,0.35,"#font[52]{m_{N}} #font[42]{#geq} #font[52]{m_{W_{R}}} #font[42]{suppressed}");
     }
   else if( sig == "ZR" )
     {
	l.SetTextAngle(32);
	l.DrawLatex(0.16,0.33,"#font[52]{m_{N}} #font[42]{#geq} #font[52]{m_{Z_{R}}/2} #font[42]{suppressed}");
     }   

   ATLASLabel(0.17,0.630,"Internal",kBlack);
   
   tc->Print("pics/limit_2d_lrsm.eps");

   gApplication->Terminate();
}

std::vector< TGraph* > getContour(TGraph2D *tgc,TCanvas *tc,const int level)
{
   TGraph *gr[1000];
   int np[1000];
   std::vector< TGraph* > res;

   TH2D *cont = tgc->GetHistogram();

   for (int ix=0;ix<cont->GetNbinsX()+1;ix++)
     for (int iy=0;iy<cont->GetNbinsY()+1;iy++)
       if (cont->GetBinContent(ix,iy)<1e-10)
	 {
	    cont->SetBinContent(ix,iy,100.0);
	 }

   cont->SetContour(1);
   cont->SetLineWidth(2);
   cont->SetContourLevel(0,1.0);
   cont->Draw("CONT Z LIST");

   tc->Update();

   TObjArray *conts = (TObjArray*)gROOT->GetListOfSpecials()->FindObject("contours");
   TList *contLevel = NULL;
   TGraph *curv = NULL;
   TGraph *gv = NULL;
   int nGraphs = 0;
   int TotalConts = conts->GetSize();

   if( TotalConts != 1 ) std::cout << "Many contour levels found !" << std::endl;
   
   for (int i=0;i<conts->GetSize(); i++)
     {
	contLevel = (TList*)conts->At(i);
	
	np[i] = 0;
	
	for (int j=0;j<contLevel->GetSize();j++)
	  {	     
	     curv = (TGraph*)contLevel->At(j);
	     curv->SetLineWidth(4);
	     gr[j]=(TGraph*)curv->Clone(Form("gr_%d",j));
	     np[i]++;
	  }
     }

   tc->Clear();

   for(int i=0;i<np[level];i++)
     res.push_back( gr[i] );

   return res;
}

void interp(TGraph* gr,int nel,double cut)
{   
   bool found = false;
   double x_cut;
   double y_cut;
   int i_cut;
   double x_fin;
   double k_fin;
   double b_fin;
   for(int ip=0;ip<nel+1;ip++)
     {
	double x_cur;
	double y_cur;
	gr->GetPoint(ip,x_cur,y_cur);
	if( x_cur < cut && y_cur > 0.2 )
	  {
	     if( !found )
	       {
		  x_cut = x_cur;
		  y_cut = y_cur;
		  i_cut = ip;
		  double xt1, xt2, yt1, yt2;
		  gr->GetPoint(ip,xt1,yt1);
		  gr->GetPoint(ip-1,xt2,yt2);
		  k_fin = (yt1-yt2)/(xt1-xt2);
		  b_fin = (yt2-k_fin*xt2+yt1-k_fin*xt1)/2.;
		  x_fin = 0.6;
		  found = true;
	       }
	     else
	       {					    
		  gr->SetPoint(ip,x_cur,k_fin*x_cur+b_fin);
	       }		       
	  }		  
     }
   gr->SetPoint(nel+1,0.6,k_fin*0.6+b_fin);
}

void interpSHARP(TGraph* gr,int nel,double cut,double k,double b)
{   
   bool found = false;
   double x_cut;
   double y_cut;
   int i_cut;
   double x_fin;
   double k_fin;
   double b_fin;
   for(int ip=0;ip<nel+1;ip++)
     {
	double x_cur;
	double y_cur;
	gr->GetPoint(ip,x_cur,y_cur);
	if( x_cur < cut && y_cur > 0.2 )
	  {
	     if( !found )
	       {
		  x_cut = x_cur;
		  y_cut = y_cur;
		  i_cut = ip;
		  double xt1, xt2, yt1, yt2;
		  gr->GetPoint(ip,xt1,yt1);
		  gr->GetPoint(ip-1,xt2,yt2);
		  k_fin = (yt1-yt2)/(xt1-xt2);
		  b_fin = (yt2-k_fin*xt2+yt1-k_fin*xt1)/2.;
		  x_fin = 0.6;
		  found = true;
	       }
	     else
	       {					    
		  gr->SetPoint(ip,x_cur,k*x_cur+b);
	       }		       
	  }		  
     }	     
   gr->SetPoint(nel+1,0.6,k*0.6+b);
}
