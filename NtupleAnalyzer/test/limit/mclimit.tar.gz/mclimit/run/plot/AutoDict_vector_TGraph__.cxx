#include "vector"
class TGraph;
#ifdef __CINT__ 
#pragma link C++ nestedclasses;
#pragma link C++ nestedtypedefs;
#pragma link C++ class vector<TGraph*>+;
#pragma link C++ class vector<TGraph*>::*;
#ifdef G__VECTOR_HAS_CLASS_ITERATOR
#pragma link C++ operators vector<TGraph*>::iterator;
#pragma link C++ operators vector<TGraph*>::const_iterator;
#pragma link C++ operators vector<TGraph*>::reverse_iterator;
#endif
#endif
