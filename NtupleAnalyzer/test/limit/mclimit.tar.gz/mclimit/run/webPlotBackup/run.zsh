#!/bin/env zsh

chan=("ee_EE" "mm_MM" "em_EM")
char=("SS" "OS")
sig=("MN" "WR")
doHTML=1

app=""

rm -rf pics/*
rm -rf html/pics/*

htmlout="html/index.html"

if [[ $doHTML == "1" ]]; then
echo "<html>" > $htmlout
echo "<head>" >> $htmlout
echo "<title>Limit input histograms</title>" >> $htmlout
echo "</head>" >> $htmlout
echo "<body>" >> $htmlout
fi

for c in $sig
do

if [[ $c == "MN" ]]; then
echo "<h1>Limit input histograms for Effective Lagrangian</h1>" >> $htmlout
else
echo "<h1>Limit input histograms for LRSM</h1>" >> $htmlout
fi

for c3 in $chan
do

echo "<h2>$c3</h2>" >> $htmlout

for c2 in $char
do

echo "<h2>$c2</h2>" >> $htmlout

hpath="/gdata/atlas/kskovpen/limit/input/2011/limit_input_FINAL"

rpath="${hpath}/signal/$c2/"

if [[ $c3 == "em_EM" && $c == "WR" ]]; then
list=$(ls $rpath | grep $c | grep "emu" | sort -tR --key=2,2n --key=3,3n -n)
else
if [[ $c == "WR" ]]; then
list=$(ls $rpath | grep $c | grep -v "emu" | sort -tR --key=2,2n --key=3,3n -n)
else
list=$(ls $rpath | grep $c | grep -v "emu" | sort -tN --key=2,2n -n)
fi
fi

echo $list | while read line
do

if [[ $c == "MN" ]]; then
if [[ ${c2} == "SS" ]]; then
cut="mll110"
else
cut="mll110_st"
fi
fsig="${hpath}/signal_adjusted/${c2}/${line}/${line}_ljj_g1jet${app}_${cut}_M_${c3}.root"
fbkg="${hpath}/output_adjusted/${line}_ljj_g1jet${app}_${cut}_M_${c3}_${c2}.root"
#fsig="${hpath}/signal_noneg/${c2}/${line}/${line}_ljj_g1jet${app}_${cut}_M_${c3}.root"
#fbkg="${hpath}/output_noneg/ljj_g1jet${app}_${cut}_M_${c3}_${c2}.root"
signame=$(echo $fsig | sed 's\_ljj.*\\g' | sed 's\.*0/\\g')
else
if [[ ${c2} == "SS" ]]; then
cut="mll110_mlljj400"
else
cut="mll110_mlljj400_st"
fi
fsig="${hpath}/signal_adjusted/${c2}/${line}/${line}_lljj_g1jet_coarse_${cut}_M_${c3}.root"
fbkg="${hpath}/output_adjusted/${line}_lljj_g1jet_coarse_${cut}_M_${c3}_${c2}.root"
#fsig="${hpath}/signal_noneg/${c2}/${line}/${line}_lljj_g1jet_coarse_${cut}_M_${c3}.root"
#fbkg="${hpath}/output_noneg/lljj_g1jet_coarse_${cut}_M_${c3}_${c2}.root"
signame=$(echo $fsig | sed 's\_lljj.*\\g' | sed 's\.*0/\\g' | sed 's\.*emu/\\g')
fi

if [[ $c == "WR" ]]; then
xaxis="M(lljj) [GeV]"
else
xaxis="M(ljj) [GeV]"
fi

root -b -l plot.C\(\"$fsig\",\"$fbkg\",\"$xaxis\"\)
mv pics/plot.eps "pics/${signame}_${c3}_${c2}.eps"

if [[ $doHTML == "1" ]]; then
convert -pointsize 42 -fill black \
-font /usr/share/fonts/default/Type1/a010013l.pfb \
-draw "text 140,220 '$signame'" "pics/${signame}_${c3}_${c2}.eps" "html/pics/${signame}_${c3}_${c2}.png"
convert -scale 120 "html/pics/${signame}_${c3}_${c2}.png" "html/pics/thumb_${signame}_${c3}_${c2}.png"
mogrify -scale 640 "html/pics/${signame}_${c3}_${c2}.png"
echo "<a href=\"pics/${signame}_${c3}_${c2}.png\" title=\"${signame}_${c3}_${c2}\"><img src=\"pics/thumb_${signame}_${c3}_${c2}.png\"></a>" >> $htmlout
fi

done
done
done
done

if [[ $doHTML == "1" ]]; then
echo "</body>" >> $htmlout
echo "</html>" >> $htmlout
tar -cvf webpage.tar html/
gzip -f webpage.tar
scp webpage.tar.gz kskovpen@lxplus.cern.ch:www/limit/.
fi
