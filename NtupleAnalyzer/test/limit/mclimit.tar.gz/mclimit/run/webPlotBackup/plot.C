void plot(TString fsig,TString fbkg,TString xaxis)
{
   gROOT->Reset();
   gROOT->SetBatch();

   gROOT->LoadMacro("/home/kskovpen/Analysis/proc/plot/atlasstyle-00-03-04/AtlasStyle.C");
   gROOT->LoadMacro("/home/kskovpen/Analysis/proc/plot/atlasstyle-00-03-04/AtlasUtils.C");
   gROOT->LoadMacro("/home/kskovpen/Analysis/proc/plot/atlasstyle-00-03-04/AtlasLabels.C");
   SetAtlasStyle();

   TFile *f_sig = NULL;
   TFile *f_bkg = NULL;
   
   if( ! gSystem->AccessPathName(fsig.Data(),kFileExists) )
     f_sig = TFile::Open(fsig.Data());
   else exit(1);
   if( ! gSystem->AccessPathName(fbkg.Data(),kFileExists) )
     f_bkg = TFile::Open(fbkg.Data());
   else exit(1);
   
   TH1F *h_signal = (TH1F*)f_sig->Get("signal");
   TH1F *h_sample_1 = (TH1F*)f_bkg->Get("sample_1");
   TH1F *h_sample_2 = (TH1F*)f_bkg->Get("sample_2");
   TH1F *h_data = (TH1F*)f_bkg->Get("data");

   TCanvas *c1 = new TCanvas();

   h_signal->SetLineColor(kRed);
   h_signal->SetLineWidth(2);
   h_signal->GetXaxis()->SetTitle(xaxis);
   h_signal->GetYaxis()->SetTitle("Number of events");

   h_sample_1->SetLineColor(kBlue);
   h_sample_1->SetMarkerColor(kBlue);
   h_sample_1->SetLineWidth(2);

   h_sample_2->SetLineColor(kMagenta);
   h_sample_2->SetMarkerColor(kMagenta);
   h_sample_2->SetLineWidth(2);

   h_data->SetMarkerColor(kBlack);
   h_data->SetMarkerStyle(20);
   
   h_signal->Draw("hist");
   h_sample_1->Draw("hist e1p same");
   h_sample_2->Draw("hist e1p same");
   h_data->Draw("e1p same");

   if( h_signal->GetMaximum() >= h_sample_1->GetMaximum() )
     h_signal->SetMaximum(h_signal->GetMaximum()+h_sample_1->GetMaximum()/2);
   else
     h_signal->SetMaximum(h_sample_1->GetMaximum()+h_signal->GetMaximum()/2);

   if( h_sample_2->GetMaximum() >= h_sample_1->GetMaximum() &&
       h_signal->GetMaximum() < h_sample_2->GetMaximum() )
     h_signal->SetMaximum(h_sample_2->GetMaximum()+h_signal->GetMaximum()/2);
   
   double int_bkg_1 = h_sample_1->Integral();
   double int_bkg_2 = h_sample_2->Integral();
   double int_bkg = int_bkg_1 + int_bkg_2;
   double int_sig = h_signal->Integral();
   
   double rat = int_bkg == 0 ? 0 : int_sig/int_bkg;
   
   if( rat < 0.1 )
     c1->SetLogy(1);
   else
     c1->SetLogy(0);
   
   TLegend *leg = new TLegend(0.75,0.93,0.93,0.72);
   leg->SetFillColor(253);
   leg->SetBorderSize(0);
   leg->AddEntry(h_signal,"Signal","f");
   leg->AddEntry(h_sample_1,"MC bkg","f");
   leg->AddEntry(h_sample_2,"FAKE bkg","f");
   leg->AddEntry(h_data,"DATA","p");
   leg->Draw();
   
   c1->Update();
   c1->Print("pics/plot.eps");
   
   gApplication->Terminate();
}

   //   gROOT->ProcessLine(".L makeErrorBand.C");   
		  
//   TGraphAsymmErrors* gr_mc = makeErrorBand(h_mc_merge,h_mc_merge_sup,h_mc_merge_sdo);
//   gr_mc->SetFillStyle(3004);
//   gStyle->SetHatchesLineWidth(2);
//   gr_mc->Draw("2SAME");
