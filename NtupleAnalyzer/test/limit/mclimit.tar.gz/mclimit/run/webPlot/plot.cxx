#include "TROOT.h"
#include "TSystem.h"
#include "TFile.h"
#include "TH2.h"
#include "Riostream.h"
#include "TMath.h"
#include "TCanvas.h"
#include "TGraph.h"
#include "TRandom.h"
#include "TParameter.h"
#include "TStopwatch.h"
#include "TLine.h"
#include "TLegend.h"
#include "TLatex.h"
#include "TKey.h"

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <math.h>

#include "atlasstyle-00-03-04/AtlasStyle.h"
#include "atlasstyle-00-03-04/AtlasUtils.h"

std::pair<int,double*> binMerger(std::map<std::string,TH1F*>);

int main(int argc, char *argv[])
{
   if( argc < 2 )
     {
        std::cout << "Usage:" << std::endl;
        std::cout << "--file: input filename" << std::endl;
        exit(1);
     }

   const char *fname_str = "test.root";

   for(int i=0;i<argc;i++)
     {
        if( ! strcmp(argv[i],"--file") ) fname_str = argv[i+1];
     }

   const char *fname  = fname_str;

   std::cout << "--file=" << fname << std::endl;

   gROOT->ProcessLine(".L atlasstyle-00-03-04/AtlasStyle.C");
   gROOT->ProcessLine(".L atlasstyle-00-03-04/AtlasUtils.C");
   gROOT->ProcessLine(".L atlasstyle-00-03-04/AtlasLabels.C");

   SetAtlasStyle();

   TFile *fin = NULL;
   
   if( ! gSystem->AccessPathName(fname,kFileExists) )
     fin = TFile::Open(fname);
   else exit(1);

   const int nvar = 1;
   std::string var[nvar] = {"mlljj"};
//   std::string var[nvar] = {"mlljjjj"};
   const int nchan = 6;
   std::string chan[nchan] = {"ee_os","mm_os","em_os","ee_ss","mm_ss","em_ss"};
   const int njet = 1;
   std::string jet[njet] = {"jge1"};
//   std::string jet[njet] = {"jge2"};
   const int nsel = 2;
   std::string sel[nsel] = {"ge_mll110_ge_st400_ge_mlljj400","ge_mll110_ge_mlljj400"};
//   std::string sel[nsel] = {"ge_mll110_ge_st200_ge_mlljjjj200","ge_mll110_ge_mlljjjj200"};
//   std::string sel[nsel] = {"le_met40_ge_mjj60_le_mjj100"};

   TCanvas *c1 = new TCanvas();

   std::cout << "Launch bin merger" << std::endl;

   int ncoll = 0;
   TH1F *hcoll[1000000];
   
   TFile *fout = new TFile("limitInput.root","RECREATE");
   
   for(int ivar=0;ivar<nvar;ivar++)
     {
	for(int ichan=0;ichan<nchan;ichan++)
	  {
	     for(int ijet=0;ijet<njet;ijet++)
	       {
		  for(int isel=0;isel<nsel;isel++)
		    {
		       TH1F *h_nom_ZJETS = NULL;
		       TH1F *h_nom_TOP = NULL;
		       TH1F *h_nom_DBX = NULL;
		       TH1F *h_nom_QCD = NULL;
		       std::string h_nom_ZJETS_name;
		       std::string h_nom_TOP_name;
		       std::string h_nom_DBX_name;
		       std::string h_nom_QCD_name;
		       
		       std::map<std::string,TH1F*> hists;

		       std::string hnameBase = var[ivar]+"_"+chan[ichan]+"_"+jet[ijet]+"_"+sel[isel];
	
		       TH1F *h_ZJETS = (TH1F*)fin->Get(("h_ZJETS_"+hnameBase).c_str());
		       TH1F *h_TOP = (TH1F*)fin->Get(("h_TOP_"+hnameBase).c_str());
		       TH1F *h_DBX = (TH1F*)fin->Get(("h_DBX_"+hnameBase).c_str());
		       TH1F *h_QCD = (TH1F*)fin->Get(("h_QCD_"+hnameBase).c_str());
		       
		       h_nom_ZJETS = (TH1F*)h_ZJETS->Clone("h_nom_ZJETS");
		       h_nom_TOP = (TH1F*)h_TOP->Clone("h_nom_TOP");
		       h_nom_DBX = (TH1F*)h_DBX->Clone("h_nom_DBX");
		       h_nom_QCD = (TH1F*)h_QCD->Clone("h_nom_QCD");
		       
		       h_nom_ZJETS_name = h_ZJETS->GetName();
		       h_nom_TOP_name = h_TOP->GetName();
		       h_nom_DBX_name = h_DBX->GetName();
		       h_nom_QCD_name = h_QCD->GetName();
		       
		       hists.insert(std::pair<std::string,TH1F*>("nom_ZJETS",h_nom_ZJETS));
		       hists.insert(std::pair<std::string,TH1F*>("nom_TOP",h_nom_TOP));
		       hists.insert(std::pair<std::string,TH1F*>("nom_DBX",h_nom_DBX));
		       hists.insert(std::pair<std::string,TH1F*>("nom_QCD",h_nom_QCD));
			  
		       std::pair<int,double*> hREBIN = binMerger(hists);
		       int nbREBIN = hREBIN.first;
		       
		       double *xbinsREBIN = hREBIN.second;
		       
		       delete h_nom_ZJETS;
		       delete h_nom_TOP;
		       delete h_nom_DBX;
		       delete h_nom_QCD;

		       fin->cd();
		       TList *dirList = gDirectory->GetListOfKeys();
		       TKey *keyLumi;
		       TIter nextkeyLumi(dirList);
		       while ((keyLumi = (TKey*)nextkeyLumi())) 
			 {
			    TH1F *h = (TH1F*)keyLumi->ReadObj();
			    std::string hnamecur = h->GetName();
			    if( std::string::npos != hnamecur.find(var[ivar]) &&
				std::string::npos != hnamecur.find(chan[ichan]) &&
				std::string::npos != hnamecur.find(jet[ijet]) &&
				std::string::npos != hnamecur.find(sel[isel]) )
			      {
//				 h = (TH1F*)h->Rebin(nbREBIN,"",xbinsREBIN);
				 // rebin to one bin
				 h = (TH1F*)h->Rebin(h->GetXaxis()->GetNbins(),"");
				 fout->cd();
				 hcoll[ncoll] = (TH1F*)h->Clone("");
				 ncoll++;
			      }
			 }      
		    }
	       }
	  }
     }   

   std::cout << "Save file with " << ncoll << " histrograms" << std::endl;
   for(int icoll=0;icoll<ncoll;icoll++)
     {
	hcoll[icoll]->Write();
     }   
   
//   std::cout << "Launch systematics monitor" << std::endl;
   
		       /*			    
		       TLine *l_all = NULL;
		       double vupStack_ZJETS[1000];
		       double vdownStack_ZJETS[1000];
		       double vupStack_TOP[1000];
		       double vdownStack_TOP[1000];
		       double vupStack_DBX[1000];
		       double vdownStack_DBX[1000];
		       for(int ib=0;ib<1000;ib++)
			 {
			    vupStack_ZJETS[ib] = 0.;
			    vdownStack_ZJETS[ib] = 0.;
			    vupStack_TOP[ib] = 0.;
			    vdownStack_TOP[ib] = 0.;
			    vupStack_DBX[ib] = 0.;
			    vdownStack_DBX[ib] = 0.;
			 }
		       
		       std::string hnameBase = var[ivar]+"_"+chan[ichan]+"_"+jet[ijet]+"_"+sel[isel];
		       std::string sysnamePlot[nsys-1];
		       double vupMaxStack_ZJETS = -666.;
		       double vdownMaxStack_ZJETS = 666.;
		       double vupMaxStack_TOP = -666.;
		       double vdownMaxStack_TOP = 666.;
		       double vupMaxStack_DBX = -666.;
		       double vdownMaxStack_DBX = 666.;

			const int nbins_ZJETS = h_ZJETS->GetXaxis()->GetNbins();
			    double xbin[nbins];
			    double vnom[nbins];
			    double vup[nbins];
			    double vdown[nbins];
			    double vupMax = -666.;
			    double vdownMax = 666.;
			    for(int ib=1;ib<=nbins;ib++)
			      {
				 vnom[ib-1] = h_nom->GetBinContent(ib);
				 vup[ib-1] = h->GetBinContent(ib);
				 vdown[ib-1] = hDown->GetBinContent(ib);
				 vup[ib-1] -= vnom[ib-1];
				 vup[ib-1] = (vnom[ib-1] > 0.) ? vup[ib-1]/vnom[ib-1] : 0.;
				 vdown[ib-1] -= vnom[ib-1];
				 vdown[ib-1] = (vnom[ib-1] > 0.) ? vdown[ib-1]/vnom[ib-1] : 0.;
				 xbin[ib-1] = ib;
				 if( vup[ib-1] > vupMax ) vupMax = vup[ib-1];
				 if( vdown[ib-1] < vdownMax ) vdownMax = vdown[ib-1];
			      }			
			    
			    TLine *lnom = new TLine(0,0,xbin[nbins-1],0);
			    lnom->SetLineStyle(2);
			    l_all = (TLine*)lnom->Clone("l_all");
			    
			    grUp[isys-1] = new TGraph(nbins,xbin,vup);
			    grDown[isys-1] = new TGraph(nbins,xbin,vdown);
			    grUp[isys-1]->SetFillColor(kRed);
			    grDown[isys-1]->SetFillColor(kBlue);
			    
			    for(int ib=1;ib<nbins;ib++)
			      {
				 vupStack[ib-1] += vup[ib-1];
				 vdownStack[ib-1] += vdown[ib-1];
				 if( vupStack[ib-1] > vupMaxStack ) vupMaxStack = vupStack[ib-1];
				 if( vdownStack[ib-1] < vdownMaxStack ) vdownMaxStack = vdownStack[ib-1];
			      }
			    grStackUp[isys-1] = new TGraph(nbins,xbin,vupStack);
			    grStackDown[isys-1] = new TGraph(nbins,xbin,vdownStack);
			    
			    grUp[isys-1]->Draw("AB");
			    grUp[isys-1]->GetYaxis()->SetRangeUser(-1.1,1.1);
			    grUp[isys-1]->GetXaxis()->SetRangeUser(0.,nbins);
			    if( vdownMax < -1. )
			      grUp[isys-1]->GetYaxis()->SetRangeUser(vdownMax*1.1,1.);
			    if( vdownMax > 1. )
			      grUp[isys-1]->GetYaxis()->SetRangeUser(-1.,vupMax*1.1);
			    if( vdownMax < -1. && vupMax > 1. )
			      grUp[isys-1]->GetYaxis()->SetRangeUser(vdownMax*1.1,vupMax*1.1);
			    grUp[isys-1]->GetXaxis()->SetTitle("Histogram bins");
			    grUp[isys-1]->GetYaxis()->SetTitle("#sigma/A");
			    grDown[isys-1]->Draw("BS");
			    lnom->Draw("SAME");
			    
			    TLatex *tex = new TLatex(1.,0.85,sysnamePlot[isys-1].c_str());
			    tex->SetTextSize(0.08);
			    tex->Draw();
			    
			    TLegend *leg = new TLegend(0.77,0.77,0.88,0.88);
			    leg->SetFillStyle(253);
			    leg->SetBorderSize(0);
			    leg->AddEntry(grUp[isys-1],"+#sigma/A","f");
			    leg->AddEntry(grDown[isys-1],"-#sigma/A","f");
			    leg->Draw();
			    
			    std::string fsave = "pics/"+hnameBase+"_"+sysname+".eps";
			    c1->Print(fsave.c_str());
			    c1->Clear();
			    
			    delete leg;
			    delete tex;*/
//			 }
/*		       TLegend *leg = new TLegend(0.77,0.25,0.88,0.88);
		       leg->SetFillColor(kWhite);

		       for(int isys=nsys-2;isys>=0;isys--)
			 {
			    if( isys == nsys-2 )
			      grStackUp[isys]->Draw("AB");
			    else
			      grStackUp[isys]->Draw("BS");
			    grStackUp[isys]->GetXaxis()->SetRangeUser(0.,grStackUp[isys]->GetN());
			    grStackUp[isys]->SetFillColor(sysColUp[isys]);
			    grStackDown[isys]->SetFillColor(sysColUp[isys]+2);
			    grStackUp[isys]->GetYaxis()->SetRangeUser(-1.1,1.1);
			    grStackUp[isys]->GetXaxis()->SetTitle("Histogram bins");
			    grStackUp[isys]->GetYaxis()->SetTitle("#sigma/A");
			    grStackDown[isys]->Draw("BS");
			    l_all->Draw("SAME");
			 }	
		       
		       if( vdownMaxStack < -1. )
			 grStackUp[nsys-2]->GetYaxis()->SetRangeUser(vdownMaxStack*1.1,1.);
		       if( vupMaxStack > 1. )
			 grStackUp[nsys-2]->GetYaxis()->SetRangeUser(-1.,vupMaxStack*1.1);
		       if( vdownMaxStack < -1. && vupMaxStack > 1. )
			 grStackUp[nsys-2]->GetYaxis()->SetRangeUser(vdownMaxStack*1.1,vupMaxStack*1.1);
		       
		       for(int isys=nsys-2;isys>=0;isys--)
			 {
			    std::string legtit = sysnamePlot[isys] + "+#sigma/A";
			    leg->AddEntry(grStackUp[isys],legtit.c_str(),"f");
			 }	
		       for(int isys=0;isys<=nsys-2;isys++)
			 {
			    std::string legtit = sysnamePlot[isys] + "-#sigma/A";
			    leg->AddEntry(grStackDown[isys],legtit.c_str(),"f");
			 }	
		       
		       leg->Draw();
		       
		       std::string fsave = "pics/"+hnameBase+"_all.eps";
		       c1->Print(fsave.c_str());
		       c1->Clear();*/

   fout->Close();
   
   delete c1;
}

std::pair<int,double*> binMerger(std::map<std::string,TH1F*> hmap)
{
   TH1F *h_nom_ZJETS = hmap.find("nom_ZJETS")->second;
   TH1F *h_nom_TOP = hmap.find("nom_TOP")->second;
   TH1F *h_nom_DBX = hmap.find("nom_DBX")->second;
   TH1F *h_nom_QCD = hmap.find("nom_QCD")->second;
   
   bool debug = false;
   
   const int nbins0 = h_nom_ZJETS->GetXaxis()->GetNbins();
   std::vector<int> binsEMPTY;
   binsEMPTY.clear();
   for(int ib=1;ib<=nbins0;ib++)
     {
	double v_ZJETS = h_nom_ZJETS->GetBinContent(ib);
	double v_TOP = h_nom_TOP->GetBinContent(ib);
	double v_DBX = h_nom_DBX->GetBinContent(ib);
	double v_QCD = h_nom_QCD->GetBinContent(ib);
	double v = v_ZJETS + v_TOP + v_DBX + v_QCD;
	if( v == 0. ) binsEMPTY.push_back(ib);
     }		
   
   TH1F *hRef = h_nom_ZJETS;
   
   std::vector<int> binsEXPAND;
   binsEXPAND.clear();
   
   int nbinsEMPTY = binsEMPTY.size();
   for(int iv=0;iv<nbinsEMPTY;iv++)
     {				 
	int idx = binsEMPTY.at(iv);
	int nexpand = 0;
	if( !(iv > 0 && idx-binsEMPTY.at(iv-1) == 1) )
	  {				      
	     for(int ib=idx+1;ib<=nbins0;ib++)
	       {
		  nexpand++;
		  if( std::find(binsEMPTY.begin(),binsEMPTY.end(),ib)==binsEMPTY.end() )
		    {
		       break;
		    }	
	       }
	  }				 
	binsEXPAND.push_back(nexpand);
     }

   if( debug )
     {	
	for(int ib=1;ib<=nbins0;ib++)
	  {
	     std::cout << ib << " " << h_nom_ZJETS->GetBinContent(ib) + h_nom_TOP->GetBinContent(ib) 
	       << " " << h_nom_ZJETS->GetXaxis()->GetBinLowEdge(ib)
		 << " " << h_nom_ZJETS->GetXaxis()->GetBinUpEdge(ib)
		   << std::endl;
	  }
	std::cout << "EXPAND" << std::endl;
	for(int iv=0;iv<nbinsEMPTY;iv++)
	  {
	     std::cout << binsEMPTY.at(iv) << " " << binsEXPAND.at(iv) << std::endl;
	  }
     }
   
   TH1F *h_nom_ZJETS_rebin = (TH1F*)h_nom_ZJETS->Clone("h_nom_ZJETS_rebin");
   double xbin_rebin[10000];
   
   xbin_rebin[0] = h_nom_ZJETS->GetXaxis()->GetBinLowEdge(1);
   int ib2 = 0;
   bool reachedMax = false;
   for(int ib=1;ib<=nbins0;ib++)
     {
	bool foundEMPTY = false;
	for(int iv=0;iv<nbinsEMPTY;iv++)
	  {	
	     int idx = binsEMPTY.at(iv);
	     if( idx == ib && binsEXPAND.at(iv) > 0 )
	       {
		  ib2++;
		  if( ib+binsEXPAND.at(iv) == nbins0 )
		    {
		       reachedMax = true;
		       xbin_rebin[ib2] = h_nom_ZJETS->GetXaxis()->GetBinUpEdge(ib+binsEXPAND.at(iv));
		    }				      
		  else
		    xbin_rebin[ib2] = h_nom_ZJETS->GetXaxis()->GetBinLowEdge(ib+binsEXPAND.at(iv));
		  foundEMPTY = true;
		  ib += binsEXPAND.at(iv);
		  break;
	       }
	  }
	if( !foundEMPTY )
	  {
	     ib2++;
	     xbin_rebin[ib2] = h_nom_ZJETS->GetXaxis()->GetBinLowEdge(ib);
	  }			   
     }
   if( !reachedMax )
     {			    
	ib2++;
	xbin_rebin[ib2] = h_nom_ZJETS->GetXaxis()->GetBinUpEdge(nbins0);
     }		       

   if( debug )
     {	
	std::cout << "RESULT" << std::endl;
	for(int ir=0;ir<=ib2;ir++)
	  {
	     std::cout << xbin_rebin[ir] << std::endl;
	  }		          
     }
   
   return std::make_pair(ib2-1,xbin_rebin);
}
