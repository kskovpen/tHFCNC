#!/bin/env zsh

appDir="/home/kskovpen/work/testarea/Limit2012/mclimit/run/webPlot"
aStyle="/home/kskovpen/work/testarea/Limit2012/mclimit/run/webPlot/atlasstyle-00-03-04"       
export LD_LIBRARY_PATH=${appDir}:${aStyle}:${LD_LIBRARY_PATH}:$ROOTSYS/lib

chan=("ee_EE" "mm_MM" "em_EM")
char=("SS" "OS")
sig=("LRSMWR")
doHTML=1

app=""

rm -rf pics/*
rm -rf html/pics/*

htmlout="html/index.html"

if [[ $doHTML == "1" ]]; then
echo "<html>" > $htmlout
echo "<head>" >> $htmlout
echo "<title>Limit input histograms</title>" >> $htmlout
echo "</head>" >> $htmlout
echo "<body>" >> $htmlout
fi

#for c in $sig
#do

#if [[ $c == "WR" ]]; then
#echo "<h1>Limit input histograms for LRSM WR</h1>" >> $htmlout
#fi

#for c3 in $chan
#do

#echo "<h2>$c3</h2>" >> $htmlout

#for c2 in $char
#do

#echo "<h2>$c2</h2>" >> $htmlout

#hpath="/home/kskovpen/work/testarea/WRHN2012/ANALYSIS_v09/17.2.4.4/SKYPlot/run/macro/limitInputLRSMWR.root"

#root -b -l plot.C\(\"$fsig\",\"$fbkg\",\"$xaxis\"\)
#mv pics/plot.eps "pics/${signame}_${c3}_${c2}.eps"

hpath="/home/kskovpen/work/testarea/WRHN2012/ANALYSIS_v09/17.2.4.4/SKYPlot/run/macro/limitInputLRSMWR.root"
#hpath="/home/kskovpen/work/testarea/WRHN2012/ANALYSIS_v09/17.2.4.4/SKYPlot/run/macro/limitInputLRSMWRMix.root"
#hpath="/home/kskovpen/work/testarea/WRHN2012/ANALYSIS_v09/17.2.4.4/SKYPlot/run/macro/limitInputWstarHNMix.root"

./plot --file ${hpath}

#if [[ $doHTML == "1" ]]; then
#convert -pointsize 42 -fill black \
#-font /usr/share/fonts/default/Type1/a010013l.pfb \
#-draw "text 140,220 '$signame'" "pics/${signame}_${c3}_${c2}.eps" "html/pics/${signame}_${c3}_${c2}.png"
#convert -scale 120 "html/pics/${signame}_${c3}_${c2}.png" "html/pics/thumb_${signame}_${c3}_${c2}.png"
#mogrify -scale 640 "html/pics/${signame}_${c3}_${c2}.png"
#echo "<a href=\"pics/${signame}_${c3}_${c2}.png\" title=\"${signame}_${c3}_${c2}\"><img src=\"pics/thumb_${signame}_${c3}_${c2}.png\"></a>" >> $htmlout
#fi

#done
#done
#done
#done

#if [[ $doHTML == "1" ]]; then
#echo "</body>" >> $htmlout
#echo "</html>" >> $htmlout
#tar -cvf webpage.tar html/
#gzip -f webpage.tar
#scp webpage.tar.gz kskovpen@lxplus.cern.ch:www/limit/.
#fi
