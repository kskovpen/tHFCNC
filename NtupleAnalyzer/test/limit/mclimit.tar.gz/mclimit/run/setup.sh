#!/bin/env sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/kskovpen/work/testarea/Limit/Diboson/limitTest/mclimit/run:$ROOTSYS/lib
